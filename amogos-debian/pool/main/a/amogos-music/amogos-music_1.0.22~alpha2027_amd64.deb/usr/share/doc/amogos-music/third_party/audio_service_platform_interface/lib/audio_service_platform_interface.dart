/*
MIT License

Copyright (c) 2021 Ryan Heise and the project contributors.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
import 'dart:ui' show Color;
import 'dart:io';

import 'package:audio_service_platform_interface/no_op_audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:meta/meta.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'method_channel_audio_service.dart';

abstract class AudioServicePlatform extends PlatformInterface {
  AudioServicePlatform() : super(token: _token);

  static final Object _token = Object();

  static AudioServicePlatform _instance =
      (!kIsWeb && (Platform.isWindows || Platform.isLinux))
          ? NoOpAudioService()
          : MethodChannelAudioService();

  static AudioServicePlatform get instance => _instance;

  static set instance(AudioServicePlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<void> configure(ConfigureRequest request) {
    throw UnimplementedError('configure() has not been implemented.');
  }

  Future<void> setState(SetStateRequest request) {
    throw UnimplementedError('setState() has not been implemented.');
  }

  Future<void> setQueue(SetQueueRequest request) {
    throw UnimplementedError('setQueue() has not been implemented.');
  }

  Future<void> setMediaItem(SetMediaItemRequest request) {
    throw UnimplementedError('setMediaItem() has not been implemented.');
  }

  Future<void> stopService(StopServiceRequest request) {
    throw UnimplementedError('stopService() has not been implemented.');
  }

  Future<void> setAndroidPlaybackInfo(
      SetAndroidPlaybackInfoRequest request) async {
    throw UnimplementedError(
        'setAndroidPlaybackInfo() has not been implemented.');
  }

  Future<void> androidForceEnableMediaButtons(
      AndroidForceEnableMediaButtonsRequest request) async {
    throw UnimplementedError(
        'androidForceEnableMediaButtons() has not been implemented.');
  }

  Future<void> notifyChildrenChanged(
      NotifyChildrenChangedRequest request) async {
    throw UnimplementedError(
        'notifyChildrenChanged() has not been implemented.');
  }

  void setHandlerCallbacks(AudioHandlerCallbacks callbacks) {
    throw UnimplementedError('setHandlerCallbacks() has not been implemented.');
  }
}

abstract class AudioHandlerCallbacks {
  Future<void> prepare(PrepareRequest request);

  Future<void> prepareFromMediaId(PrepareFromMediaIdRequest request);

  Future<void> prepareFromSearch(PrepareFromSearchRequest request);

  Future<void> prepareFromUri(PrepareFromUriRequest request);

  Future<void> play(PlayRequest request);

  Future<void> playFromMediaId(PlayFromMediaIdRequest request);

  Future<void> playFromSearch(PlayFromSearchRequest request);

  Future<void> playFromUri(PlayFromUriRequest request);

  Future<void> playMediaItem(PlayMediaItemRequest request);

  Future<void> pause(PauseRequest request);

  Future<void> click(ClickRequest request);

  Future<void> stop(StopRequest request);

  Future<void> addQueueItem(AddQueueItemRequest request);

  Future<void> insertQueueItem(InsertQueueItemRequest request);

  Future<void> removeQueueItem(RemoveQueueItemRequest request);

  Future<void> removeQueueItemAt(RemoveQueueItemAtRequest request);

  Future<void> skipToNext(SkipToNextRequest request);

  Future<void> skipToPrevious(SkipToPreviousRequest request);

  Future<void> fastForward(FastForwardRequest request);

  Future<void> rewind(RewindRequest request);

  Future<void> skipToQueueItem(SkipToQueueItemRequest request);

  Future<void> seek(SeekRequest request);

  Future<void> setRating(SetRatingRequest request);

  Future<void> setCaptioningEnabled(SetCaptioningEnabledRequest request);

  Future<void> setRepeatMode(SetRepeatModeRequest request);

  Future<void> setShuffleMode(SetShuffleModeRequest request);

  Future<void> seekBackward(SeekBackwardRequest request);

  Future<void> seekForward(SeekForwardRequest request);

  Future<void> setSpeed(SetSpeedRequest request);

  Future<dynamic> customAction(CustomActionRequest request);

  Future<void> onTaskRemoved(OnTaskRemovedRequest request);

  Future<void> onNotificationDeleted(OnNotificationDeletedRequest request);

  Future<void> onNotificationClicked(OnNotificationClickedRequest request);

  Future<GetChildrenResponse> getChildren(GetChildrenRequest request);

  Future<GetMediaItemResponse> getMediaItem(GetMediaItemRequest request);

  Future<SearchResponse> search(SearchRequest request);

  Future<void> androidSetRemoteVolume(AndroidSetRemoteVolumeRequest request);

  Future<void> androidAdjustRemoteVolume(
      AndroidAdjustRemoteVolumeRequest request);
}

enum AudioProcessingStateMessage {
  idle,

  loading,

  buffering,

  ready,

  completed,

  error,
}

enum MediaActionMessage {
  stop,
  pause,
  play,
  rewind,
  skipToPrevious,
  skipToNext,
  fastForward,
  setRating,
  seek,
  playPause,
  playFromMediaId,
  playFromSearch,
  skipToQueueItem,
  playFromUri,
  prepare,
  prepareFromMediaId,
  prepareFromSearch,
  prepareFromUri,
  setRepeatMode,

  _setShuffleModeEnabled,
  setCaptioningEnabled,
  setShuffleMode,

  seekBackward,
  seekForward,
  setSpeed,

  custom,
}

class MediaControlMessage {
  final String androidIcon;

  final String label;

  final MediaActionMessage action;

  final CustomMediaActionMessage? customAction;

  @literal
  const MediaControlMessage({
    required this.androidIcon,
    required this.label,
    required this.action,
    this.customAction,
  });

  Map<String, dynamic> toMap() => <String, dynamic>{
        'androidIcon': androidIcon,
        'label': label,
        'action': action.index,
        if (customAction != null) 'customAction': customAction?.toMap(),
      };
}

class CustomMediaActionMessage {
  final String name;

  final Map<String, dynamic>? extras;

  CustomMediaActionMessage({required this.name, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'name': name,
        'extras': extras,
      };
}

class PlaybackStateMessage {
  final AudioProcessingStateMessage processingState;

  final bool playing;

  final List<MediaControlMessage> controls;

  final List<int>? androidCompactActionIndices;

  final Set<MediaActionMessage> systemActions;

  final Duration updatePosition;

  final Duration bufferedPosition;

  final double speed;

  final DateTime updateTime;

  final int? errorCode;

  final String? errorMessage;

  final AudioServiceRepeatModeMessage repeatMode;

  final AudioServiceShuffleModeMessage shuffleMode;

  final bool captioningEnabled;

  final int? queueIndex;

  PlaybackStateMessage({
    this.processingState = AudioProcessingStateMessage.idle,
    this.playing = false,
    this.controls = const [],
    this.androidCompactActionIndices,
    this.systemActions = const {},
    this.updatePosition = Duration.zero,
    this.bufferedPosition = Duration.zero,
    this.speed = 1.0,
    DateTime? updateTime,
    this.errorCode,
    this.errorMessage,
    this.repeatMode = AudioServiceRepeatModeMessage.none,
    this.shuffleMode = AudioServiceShuffleModeMessage.none,
    this.captioningEnabled = false,
    this.queueIndex,
  })  : assert(androidCompactActionIndices == null ||
            androidCompactActionIndices.length <= 3),
        updateTime = updateTime ?? DateTime.now();

  factory PlaybackStateMessage.fromMap(Map<String, dynamic> map) =>
      PlaybackStateMessage(
        processingState:
            AudioProcessingStateMessage.values[map['processingState'] as int],
        playing: map['playing'] as bool,
        controls: const [],
        androidCompactActionIndices: null,
        systemActions: (map['systemActions'] as List)
            .map((dynamic action) => MediaActionMessage.values[action as int])
            .toSet(),
        updatePosition: Duration(microseconds: map['updatePosition'] as int),
        bufferedPosition:
            Duration(microseconds: map['bufferedPosition'] as int),
        speed: map['speed'] as double,
        updateTime:
            DateTime.fromMillisecondsSinceEpoch(map['updateTime'] as int),
        errorCode: map['errorCode'] as int?,
        errorMessage: map['errorMessage'] as String?,
        repeatMode:
            AudioServiceRepeatModeMessage.values[map['repeatMode'] as int],
        shuffleMode:
            AudioServiceShuffleModeMessage.values[map['shuffleMode'] as int],
        captioningEnabled: map['captioningEnabled'] as bool,
        queueIndex: map['queueIndex'] as int?,
      );

  Map<String, dynamic> toMap() => <String, dynamic>{
        'processingState': processingState.index,
        'playing': playing,
        'controls': controls.map((control) => control.toMap()).toList(),
        'androidCompactActionIndices': androidCompactActionIndices,
        'systemActions': systemActions.map((action) => action.index).toList(),
        'updatePosition': updatePosition.inMilliseconds,
        'bufferedPosition': bufferedPosition.inMilliseconds,
        'speed': speed,
        'updateTime': updateTime.millisecondsSinceEpoch,
        'errorCode': errorCode,
        'errorMessage': errorMessage,
        'repeatMode': repeatMode.index,
        'shuffleMode': shuffleMode.index,
        'captioningEnabled': captioningEnabled,
        'queueIndex': queueIndex,
      };
}

class AndroidVolumeDirectionMessage {
  static const lower = AndroidVolumeDirectionMessage(-1);
  static const same = AndroidVolumeDirectionMessage(0);
  static const raise = AndroidVolumeDirectionMessage(1);
  static const values = <int, AndroidVolumeDirectionMessage>{
    -1: lower,
    0: same,
    1: raise,
  };
  final int index;

  @literal
  const AndroidVolumeDirectionMessage(this.index);

  @override
  String toString() => '$index';
}

class AndroidPlaybackTypeMessage {
  static const local = AndroidPlaybackTypeMessage(1);
  static const remote = AndroidPlaybackTypeMessage(2);
  final int index;

  @literal
  const AndroidPlaybackTypeMessage(this.index);

  @override
  String toString() => '$index';
}

enum AndroidVolumeControlTypeMessage { fixed, relative, absolute }

abstract class AndroidPlaybackInfoMessage {
  @literal
  const AndroidPlaybackInfoMessage();

  Map<String, dynamic> toMap();
}

class RemoteAndroidPlaybackInfoMessage extends AndroidPlaybackInfoMessage {
  final AndroidVolumeControlTypeMessage volumeControlType;
  final int maxVolume;
  final int volume;

  @literal
  const RemoteAndroidPlaybackInfoMessage({
    required this.volumeControlType,
    required this.maxVolume,
    required this.volume,
  });

  @override
  Map<String, dynamic> toMap() => <String, dynamic>{
        'playbackType': AndroidPlaybackTypeMessage.remote.index,
        'volumeControlType': volumeControlType.index,
        'maxVolume': maxVolume,
        'volume': volume,
      };

  @override
  String toString() => '${toMap()}';
}

class LocalAndroidPlaybackInfoMessage extends AndroidPlaybackInfoMessage {
  @literal
  const LocalAndroidPlaybackInfoMessage();

  @override
  Map<String, dynamic> toMap() => <String, dynamic>{
        'playbackType': AndroidPlaybackTypeMessage.local.index,
      };

  @override
  String toString() => '${toMap()}';
}

enum MediaButtonMessage {
  media,
  next,
  previous,
}

enum AudioServiceShuffleModeMessage { none, all, group }

enum AudioServiceRepeatModeMessage {
  none,

  one,

  all,

  group,
}

class MediaItemMessage {
  final String id;

  final String title;

  final String? album;

  final String? artist;

  final String? genre;

  final Duration? duration;

  final Uri? artUri;

  final bool? playable;

  final String? displayTitle;

  final String? displaySubtitle;

  final String? displayDescription;

  final RatingMessage? rating;

  final Map<String, dynamic>? extras;

  @literal
  const MediaItemMessage({
    required this.id,
    required this.title,
    this.album,
    this.artist,
    this.genre,
    this.duration,
    this.artUri,
    this.playable = true,
    this.displayTitle,
    this.displaySubtitle,
    this.displayDescription,
    this.rating,
    this.extras,
  });

  factory MediaItemMessage.fromMap(Map<String, dynamic> raw) =>
      MediaItemMessage(
        id: raw['id'] as String,
        title: raw['title'] as String,
        album: raw['album'] as String?,
        artist: raw['artist'] as String?,
        genre: raw['genre'] as String?,
        duration: raw['duration'] != null
            ? Duration(milliseconds: raw['duration'] as int)
            : null,
        artUri:
            raw['artUri'] != null ? Uri.parse(raw['artUri'] as String) : null,
        playable: raw['playable'] as bool?,
        displayTitle: raw['displayTitle'] as String?,
        displaySubtitle: raw['displaySubtitle'] as String?,
        displayDescription: raw['displayDescription'] as String?,
        rating: raw['rating'] != null
            ? RatingMessage.fromMap(
                _castMap(raw['rating'] as Map<dynamic, dynamic>)!)
            : null,
        extras: _castMap(raw['extras'] as Map<dynamic, dynamic>?),
      );

  Map<String, dynamic> toMap() => <String, dynamic>{
        'id': id,
        'title': title,
        'album': album,
        'artist': artist,
        'genre': genre,
        'duration': duration?.inMilliseconds,
        'artUri': artUri?.toString(),
        'playable': playable,
        'displayTitle': displayTitle,
        'displaySubtitle': displaySubtitle,
        'displayDescription': displayDescription,
        'rating': rating?.toMap(),
        'extras': extras,
      };
}

class RatingMessage {
  final RatingStyleMessage type;
  final Object? value;

  @literal
  const RatingMessage({required this.type, required this.value});

  double get percentRating {
    if (type != RatingStyleMessage.percentage) return -1;
    final localValue = value as double?;
    if (localValue == null || localValue < 0 || localValue > 100) return -1;
    return localValue;
  }

  int get starRating {
    if (type != RatingStyleMessage.range3stars &&
        type != RatingStyleMessage.range4stars &&
        type != RatingStyleMessage.range5stars) {
      return -1;
    }
    return value as int? ?? -1;
  }

  bool get hasHeart {
    if (type != RatingStyleMessage.heart) return false;
    return value as bool? ?? false;
  }

  bool get isThumbUp {
    if (type != RatingStyleMessage.thumbUpDown) return false;
    return value as bool? ?? false;
  }

  bool get isRated => value != null;

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'type': type.index,
      'value': value,
    };
  }

  RatingMessage.fromMap(Map<String, dynamic> raw)
      : this(
          type: RatingStyleMessage.values[raw['type'] as int],
          value: raw['value'],
        );

  @override
  String toString() => '${toMap()}';
}

enum RatingStyleMessage {
  none,

  heart,

  thumbUpDown,

  range3stars,

  range4stars,

  range5stars,

  percentage,
}

class OnNotificationClickedRequest {
  final bool clicked;

  @literal
  const OnNotificationClickedRequest({required this.clicked});

  factory OnNotificationClickedRequest.fromMap(Map<String, dynamic> map) =>
      OnNotificationClickedRequest(
        clicked: map['clicked'] == null,
      );

  Map<String, dynamic> toMap() => <String, dynamic>{
        'clicked': clicked,
      };
}

class SetStateRequest {
  final PlaybackStateMessage state;

  @literal
  const SetStateRequest({required this.state});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'state': state.toMap(),
      };
}

class SetQueueRequest {
  final List<MediaItemMessage> queue;

  @literal
  const SetQueueRequest({required this.queue});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'queue': queue.map((item) => item.toMap()).toList(),
      };
}

class SetMediaItemRequest {
  final MediaItemMessage mediaItem;

  const SetMediaItemRequest({required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItem': mediaItem.toMap(),
      };
}

class StopServiceRequest {
  @literal
  const StopServiceRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class SetAndroidPlaybackInfoRequest {
  final AndroidPlaybackInfoMessage playbackInfo;

  @literal
  const SetAndroidPlaybackInfoRequest({required this.playbackInfo});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'playbackInfo': playbackInfo.toMap(),
      };
}

class AndroidForceEnableMediaButtonsRequest {
  @literal
  const AndroidForceEnableMediaButtonsRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class NotifyChildrenChangedRequest {
  final String parentMediaId;
  final Map<String, dynamic>? options;

  @literal
  const NotifyChildrenChangedRequest({
    required this.parentMediaId,
    this.options,
  });

  Map<String, dynamic> toMap() => <String, dynamic>{
        'parentMediaId': parentMediaId,
        'options': options,
      };
}

class PrepareRequest {
  @literal
  const PrepareRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class PrepareFromMediaIdRequest {
  final String mediaId;
  final Map<String, dynamic>? extras;

  @literal
  const PrepareFromMediaIdRequest({required this.mediaId, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaId': mediaId,
      };
}

class PrepareFromSearchRequest {
  final String query;
  final Map<String, dynamic>? extras;

  @literal
  const PrepareFromSearchRequest({required this.query, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'query': query,
        'extras': extras,
      };
}

class PrepareFromUriRequest {
  final Uri uri;
  final Map<String, dynamic>? extras;

  @literal
  const PrepareFromUriRequest({required this.uri, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'uri': uri.toString(),
        'extras': extras,
      };
}

class PlayRequest {
  @literal
  const PlayRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class PlayFromMediaIdRequest {
  final String mediaId;
  final Map<String, dynamic>? extras;

  @literal
  const PlayFromMediaIdRequest({required this.mediaId, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaId': mediaId,
      };
}

class PlayFromSearchRequest {
  final String query;
  final Map<String, dynamic>? extras;

  @literal
  const PlayFromSearchRequest({required this.query, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'query': query,
        'extras': extras,
      };
}

class PlayFromUriRequest {
  final Uri uri;
  final Map<String, dynamic>? extras;

  @literal
  const PlayFromUriRequest({required this.uri, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'uri': uri.toString(),
        'extras': extras,
      };
}

class PlayMediaItemRequest {
  final MediaItemMessage mediaItem;

  @literal
  const PlayMediaItemRequest({required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItem': mediaItem.toMap(),
      };
}

class PauseRequest {
  @literal
  const PauseRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class ClickRequest {
  final MediaButtonMessage button;

  @literal
  const ClickRequest({required this.button});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'button': button.index,
      };
}

class StopRequest {
  @literal
  const StopRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class AddQueueItemRequest {
  final MediaItemMessage mediaItem;

  @literal
  const AddQueueItemRequest({required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItem': mediaItem.toMap(),
      };
}

class InsertQueueItemRequest {
  final int index;
  final MediaItemMessage mediaItem;

  @literal
  const InsertQueueItemRequest({required this.index, required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'index': index,
        'mediaItem': mediaItem.toMap(),
      };
}

class RemoveQueueItemRequest {
  final MediaItemMessage mediaItem;

  @literal
  const RemoveQueueItemRequest({required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItem': mediaItem.toMap(),
      };
}

class RemoveQueueItemAtRequest {
  final int index;

  @literal
  const RemoveQueueItemAtRequest({required this.index});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'index': index,
      };
}

class SkipToNextRequest {
  @literal
  const SkipToNextRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class SkipToPreviousRequest {
  @literal
  const SkipToPreviousRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class FastForwardRequest {
  @literal
  const FastForwardRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class RewindRequest {
  @literal
  const RewindRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class SkipToQueueItemRequest {
  final int index;

  @literal
  const SkipToQueueItemRequest({required this.index});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'index': index,
      };
}

class SeekRequest {
  final Duration position;

  @literal
  const SeekRequest({required this.position});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'position': position.inMicroseconds,
      };
}

class SetRatingRequest {
  final RatingMessage rating;
  final Map<String, dynamic>? extras;

  @literal
  const SetRatingRequest({required this.rating, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'rating': rating.toMap(),
        'extras': extras,
      };
}

class SetCaptioningEnabledRequest {
  final bool enabled;

  @literal
  const SetCaptioningEnabledRequest({required this.enabled});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'enabled': enabled,
      };
}

class SetRepeatModeRequest {
  final AudioServiceRepeatModeMessage repeatMode;

  @literal
  const SetRepeatModeRequest({required this.repeatMode});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'repeatMode': repeatMode.index,
      };
}

class SetShuffleModeRequest {
  final AudioServiceShuffleModeMessage shuffleMode;

  @literal
  const SetShuffleModeRequest({required this.shuffleMode});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'shuffleMode': shuffleMode.index,
      };
}

class SeekBackwardRequest {
  final bool begin;

  @literal
  const SeekBackwardRequest({required this.begin});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'begin': begin,
      };
}

class SeekForwardRequest {
  final bool begin;

  @literal
  const SeekForwardRequest({required this.begin});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'begin': begin,
      };
}

class SetSpeedRequest {
  final double speed;

  @literal
  const SetSpeedRequest({required this.speed});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'speed': speed,
      };
}

class CustomActionRequest {
  final String name;
  final Map<String, dynamic>? extras;

  @literal
  const CustomActionRequest({required this.name, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'name': name,
        'extras': extras,
      };
}

class OnTaskRemovedRequest {
  @literal
  const OnTaskRemovedRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class OnNotificationDeletedRequest {
  @literal
  const OnNotificationDeletedRequest();

  Map<String, dynamic> toMap() => <String, dynamic>{};
}

class GetChildrenRequest {
  final String parentMediaId;
  final Map<String, dynamic>? options;

  @literal
  const GetChildrenRequest({required this.parentMediaId, this.options});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'parentMediaId': parentMediaId,
        'options': options,
      };
}

class GetChildrenResponse {
  final List<MediaItemMessage> children;

  @literal
  const GetChildrenResponse({required this.children});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'children': children.map((item) => item.toMap()).toList(),
      };
}

class GetMediaItemRequest {
  final String mediaId;

  @literal
  const GetMediaItemRequest({required this.mediaId});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaId': mediaId,
      };
}

class GetMediaItemResponse {
  final MediaItemMessage? mediaItem;

  @literal
  const GetMediaItemResponse({required this.mediaItem});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItem': mediaItem?.toMap(),
      };
}

class SearchRequest {
  final String query;
  final Map<String, dynamic>? extras;

  @literal
  const SearchRequest({required this.query, this.extras});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'query': query,
        'extras': extras,
      };
}

class SearchResponse {
  final List<MediaItemMessage> mediaItems;

  @literal
  const SearchResponse({required this.mediaItems});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'mediaItems': mediaItems.map((item) => item.toMap()).toList(),
      };
}

class AndroidSetRemoteVolumeRequest {
  final int volumeIndex;

  @literal
  const AndroidSetRemoteVolumeRequest({required this.volumeIndex});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'volumeIndex': volumeIndex,
      };
}

class AndroidAdjustRemoteVolumeRequest {
  final AndroidVolumeDirectionMessage direction;

  @literal
  const AndroidAdjustRemoteVolumeRequest({required this.direction});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'direction': direction.index,
      };
}

class ConfigureRequest {
  final AudioServiceConfigMessage config;

  @literal
  const ConfigureRequest({required this.config});

  Map<String, dynamic> toMap() => <String, dynamic>{
        'config': config.toMap(),
      };
}

class AudioServiceConfigMessage {
  final bool androidResumeOnClick;

  final String? androidNotificationChannelId;

  final String androidNotificationChannelName;

  final String? androidNotificationChannelDescription;

  final Color? notificationColor;

  final String androidNotificationIcon;

  final bool androidShowNotificationBadge;

  final bool androidNotificationClickStartsActivity;

  final bool androidNotificationOngoing;

  final bool androidStopForegroundOnPause;

  final int? artDownscaleWidth;

  final int? artDownscaleHeight;

  final Duration fastForwardInterval;

  final Duration rewindInterval;

  final bool preloadArtwork;

  final Map<String, dynamic>? androidBrowsableRootExtras;

  @literal
  const AudioServiceConfigMessage({
    this.androidResumeOnClick = true,
    this.androidNotificationChannelId,
    this.androidNotificationChannelName = 'Notifications',
    this.androidNotificationChannelDescription,
    this.notificationColor,
    this.androidNotificationIcon = 'mipmap/ic_launcher',
    this.androidShowNotificationBadge = false,
    this.androidNotificationClickStartsActivity = true,
    this.androidNotificationOngoing = false,
    this.androidStopForegroundOnPause = true,
    this.artDownscaleWidth,
    this.artDownscaleHeight,
    this.fastForwardInterval = const Duration(seconds: 10),
    this.rewindInterval = const Duration(seconds: 10),
    this.preloadArtwork = false,
    this.androidBrowsableRootExtras,
  })  : assert((artDownscaleWidth != null) == (artDownscaleHeight != null)),
        assert(fastForwardInterval > Duration.zero),
        assert(rewindInterval > Duration.zero),
        assert(
          !androidNotificationOngoing || androidStopForegroundOnPause,
          'The androidNotificationOngoing will make no effect with androidStopForegroundOnPause set to false',
        );

  Map<String, dynamic> toMap() => <String, dynamic>{
        'androidResumeOnClick': androidResumeOnClick,
        'androidNotificationChannelId': androidNotificationChannelId,
        'androidNotificationChannelName': androidNotificationChannelName,
        'androidNotificationChannelDescription':
            androidNotificationChannelDescription,
        'notificationColor': notificationColor?.value,
        'androidNotificationIcon': androidNotificationIcon,
        'androidShowNotificationBadge': androidShowNotificationBadge,
        'androidNotificationClickStartsActivity':
            androidNotificationClickStartsActivity,
        'androidNotificationOngoing': androidNotificationOngoing,
        'androidStopForegroundOnPause': androidStopForegroundOnPause,
        'artDownscaleWidth': artDownscaleWidth,
        'artDownscaleHeight': artDownscaleHeight,
        'fastForwardInterval': fastForwardInterval.inMilliseconds,
        'rewindInterval': rewindInterval.inMilliseconds,
        'preloadArtwork': preloadArtwork,
        'androidBrowsableRootExtras': androidBrowsableRootExtras,
      };
}

@pragma('vm:prefer-inline')
Map<String, dynamic>? _castMap(Map<dynamic, dynamic>? map) =>
    map?.cast<String, dynamic>();
