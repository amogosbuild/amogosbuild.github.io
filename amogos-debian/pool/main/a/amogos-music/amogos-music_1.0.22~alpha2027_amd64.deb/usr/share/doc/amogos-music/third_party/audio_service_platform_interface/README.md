# Audio service platform interface compatibility

Based on Ryan Heise's MIT-licensed audio_service_platform_interface 0.1.1,
downloaded from https://pub.dev/api/archives/audio_service_platform_interface-0.1.1.tar.gz.

The only functional modification imports `Color` explicitly from `dart:ui`,
because Flutter 3.0.5 does not export it through `flutter/services.dart`.
Documentation comments are consolidated into the retained MIT notice to follow
this project's comment limit. Runtime messages and methods remain unchanged.

This enables audio_service 0.18.13's Android 13 custom media controls without
requiring audio_session 0.1.19+, which raises the iOS minimum to 12. Android
remains API 21 and the application's iOS source floor remains 9.0.
