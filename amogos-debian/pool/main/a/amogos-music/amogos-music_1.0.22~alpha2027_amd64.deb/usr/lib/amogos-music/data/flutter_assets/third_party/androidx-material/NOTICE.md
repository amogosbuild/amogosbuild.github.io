# AndroidX Material 3 wave adaptation

`lib/ui/widgets/material_wavy_progress.dart` adapts the quadratic wave path, measured-path phase offset, cap-aware gap, shrinking stop indicator and determinate tokens from AndroidX Material 3. Copyright 2024–2025 The Android Open Source Project. Licensed under Apache License 2.0; see LICENSE in this directory.

Sources:

Wave geometry inspected at upstream revision `7ac433e44e797de53af85226797862687f37735f`. This directory is bundled as Flutter assets so distributed builds retain this notice and the license.

- https://github.com/androidx/androidx/blob/androidx-main/compose/material3/material3/src/commonMain/kotlin/androidx/compose/material3/internal/LinearWavyProgressModifiers.kt
- https://github.com/androidx/androidx/blob/androidx-main/compose/material3/material3/src/commonMain/kotlin/androidx/compose/material3/WavyProgressIndicator.kt
- https://github.com/androidx/androidx/blob/androidx-main/compose/material3/material3/src/commonMain/kotlin/androidx/compose/material3/tokens/LinearProgressIndicatorTokens.kt

Flutter 3.0.5 has no built-in Material 3 wavy progress component. This Dart adaptation retains Flutter's seek slider gestures and accessibility across platforms. It uses the official 40 dp wavelength, 4 dp stroke/gap, 10 dp height, quadratic path and one-wavelength-per-second linear phase. Amplitude changes use the official progress thresholds (10% and 95%) and 400 ms easing. Playback pause, reduced motion, obscured routes and background lifecycle states suspend motion.
